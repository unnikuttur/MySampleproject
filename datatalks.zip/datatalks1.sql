/*
SQLyog Community v13.1.1 (64 bit)
MySQL - 5.6.42 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

CREATE DATABASE datatalks;
use datatalks;

create table `user` (
	`id` bigint (20),
	`password` varchar (765),
	`username` varchar (765),
	`usertype` varchar (765)
); 

create table `audit` (
	`id` bigint (20),
	`upddate` datetime ,
	`uri` varchar (765),
	`username` varchar (765)
); 

create table `role` (
	`id` bigint (20),
	`name` varchar (765)
); 
insert into `role` (`id`, `name`) values('1','ROLE_ADMIN');
insert into `role` (`id`, `name`) values('2','ROLE_USER');

create table `user_roles` (
	`users_id` bigint (20),
	`roles_id` bigint (20)
); 