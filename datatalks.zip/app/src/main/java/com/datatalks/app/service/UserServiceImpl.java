package com.datatalks.app.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.datatalks.app.model.Role;
import com.datatalks.app.model.User;
import com.datatalks.app.repository.RoleRepository;
import com.datatalks.app.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	private static final String STR_TWO = "2";
	private static final String STR_ONE = "1";
	private static final String STR_USER = "U";
	private static final String STR_ADMIN = "A";
	private static final String STR_DUMMY_ROLE = "11111";	
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public void save(User user) {
		/*
		 * user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		 * user.setRoles(new HashSet<>(roleRepository.findAll()));
		 * userRepository.save(user);
		 */
    	
    	Role roleObj;
		Set<Role> roleSet = new HashSet<>();
		user.setPassword(this.bCryptPasswordEncoder.encode(user.getPassword()));
		// condition for normal user routing
		if (STR_USER.equals(user.getUsertype()))
		{
			roleObj = this.roleRepository.getOne(Long.valueOf(STR_TWO));
			roleSet.add(roleObj);
			user.setRoles(roleSet);
		}
		// condition for super user routing
		else if (STR_ADMIN.equals(user.getUsertype()))
		{
			roleObj = this.roleRepository.getOne(Long.valueOf(STR_ONE));
			roleSet.add(roleObj);
			user.setRoles(roleSet);
		}
		
		user.setRole(STR_DUMMY_ROLE);
		this.userRepository.save(user);
    }

    @Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
}
