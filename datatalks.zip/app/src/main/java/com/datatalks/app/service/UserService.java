package com.datatalks.app.service;

import com.datatalks.app.model.User;

/**
 * @author vasudevan
 * 
 * service related user related things
 *
 */
public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
