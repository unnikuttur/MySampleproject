package com.datatalks.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.datatalks.app.model.Audit;
import com.datatalks.app.repository.AuditRepository;

@Service
public class AuditServiceImpl implements AuditService {
	@Autowired
	private AuditRepository auditRepository;

	@Override
	public void save(Audit audit) {
		// TODO Auto-generated method stub
		auditRepository.save(audit);
	}

}
