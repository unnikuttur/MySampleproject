package com.datatalks.app.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.datatalks.app.model.Audit;
import com.datatalks.app.model.User;
import com.datatalks.app.service.AuditService;
import com.datatalks.app.service.SecurityService;
import com.datatalks.app.service.UserService;
import com.datatalks.app.validator.UserValidator;

/**
 * @author vasudevan
 * 
 * controller for login and user creation
 *
 */
@Controller
public class UserController {
	private static final String PAGE_ADMIN_HOME = "adminPage";
	private static final String PAGE_LOGIN = "login";
	private static final String PAGE_USER_HOME = "userPage";
	private static final String ERROR = "error";
	private static final String ERROR_MESSAGE_INVALID_USER_CREDENTIALS = "Your username or password is invalid.";
	private static final String ADMIN_ROLE = "ROLE_ADMIN";
	private static final String USER_ROLE = "ROLE_USER";
	@Autowired
	private UserService userService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	private AuditService auditService;

	@Autowired
	private transient AuthenticationManager authenticationManager;

	@Autowired
	private transient UserDetailsService userDetailsService;

	@GetMapping("/registration")
	public String registration(Model model) {
		model.addAttribute("userForm", new User());

		return "registration";
	}

	@PostMapping("/registration")
	public String registration(@ModelAttribute("userForm") User userForm, BindingResult bindingResult) {
		userValidator.validate(userForm, bindingResult);

		if (bindingResult.hasErrors()) {
			return "registration";
		}

		userService.save(userForm);

		securityService.autoLogin(userForm.getUsername(), userForm.getPasswordConfirm());

		return "redirect:/welcome";
	}

	@PostMapping("/audit")
	public void audit(HttpServletRequest request,HttpServletResponse response) {
		Audit audit=new Audit();
		audit.setUsername(request.getAttribute("username").toString());
		audit.setUri(request.getAttribute("uri").toString());
		//model.addAttribute("auditForm", audit);
		
		System.out.println("**************************************");
		auditService.save(audit);
	}

	

	@GetMapping("/login")
	public String login(Model model, String error, String logout) {
		if (error != null)
			model.addAttribute("error", "Your username and password is invalid.");

		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");

		
		return "login";

	}

	@GetMapping({ "/", "/welcome" })
	public String login(@ModelAttribute("loginForm") User userForm, Model model, HttpServletRequest request,
			HttpServletResponse response) {

		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = null;
		UserDetails userDetails = null;
		try {
			userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (userDetails.getAuthorities().toString().contains(ADMIN_ROLE)) {
				return PAGE_ADMIN_HOME;

			}
			if (userDetails.getAuthorities().toString().contains(USER_ROLE)) {
				return PAGE_USER_HOME;

			}

			
		} catch (AuthenticationException ex) {

			System.out.println(ex);
			model.addAttribute(ERROR, ERROR_MESSAGE_INVALID_USER_CREDENTIALS);
			return PAGE_LOGIN;

		}
		return PAGE_LOGIN;
	}

	/*
	 * @GetMapping({"/", "/welcome"}) public String welcome(Model model) { return
	 * "welcome"; }
	 */
}
