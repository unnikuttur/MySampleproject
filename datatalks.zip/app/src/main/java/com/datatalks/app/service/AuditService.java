package com.datatalks.app.service;

import com.datatalks.app.model.Audit;

/**
 * @author vasudevan
 * 
 * service interface which contain all services for Audit
 *
 */
public interface AuditService {
	void save(Audit audit);

}
