package com.datatalks.app.interceptor;

import java.lang.reflect.Method;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.datatalks.app.model.Audit;
import com.datatalks.app.service.AuditService;

/**
 * @author vasudevan.kk
 * 
 * This Interceptor class for check the requests.
 *
 */
@Component
public class AuditInterceptor extends HandlerInterceptorAdapter {
	@Autowired
	private AuditService auditService;
	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	@Override
	public boolean preHandle(HttpServletRequest requestServlet, HttpServletResponse responseServlet, Object handler)
			throws Exception {
		System.out.println("MINIMAL: INTERCEPTOR PREHANDLE CALLED");
		if (handler instanceof HandlerMethod) {
			HandlerMethod handlerMethod = (HandlerMethod) handler;
			Method method = handlerMethod.getMethod();
			LOGGER.info("input methods----->" + requestServlet.getMethod() + " " + requestServlet.getRequestURI()
					+ " " + method.getName() + " " + handlerMethod.getBean().getClass());
			try {
				UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication()
						.getPrincipal();
				Audit audit = new Audit();
				audit.setUsername(userDetails.getUsername());
				audit.setUri(requestServlet.getRequestURI());
				audit.setUpddate(new Date());				
				auditService.save(audit);
				
			} catch (Exception ae) {
				
				LOGGER.error("Exception occured "+ae);
			}
			

		}

		return true;
	}
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		//System.out.println("MINIMAL: INTERCEPTOR POSTHANDLE CALLED");
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception exception) throws Exception {
		//System.out.println("MINIMAL: INTERCEPTOR AFTERCOMPLETION CALLED");
	}

}
