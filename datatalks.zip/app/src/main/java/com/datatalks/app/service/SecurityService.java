package  com.datatalks.app.service;

/**
 * @author vasudevan
 * 
 * service interface which contain all services for Security related operation
 *
 */
public interface SecurityService {
    String findLoggedInUsername();

    void autoLogin(String username, String password);
}
