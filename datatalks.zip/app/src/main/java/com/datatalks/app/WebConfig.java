package com.datatalks.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.datatalks.app.interceptor.AuditInterceptor;

/**
 * @author vasudevan
 * 
 * configuration class
 *
 */
@Configuration
public class WebConfig implements WebMvcConfigurer{
	
	@Override
    public void addInterceptors(InterceptorRegistry registry)
    {
        registry.addInterceptor(pageAuditInterceptor());
    }
	
	@SuppressWarnings("unused")
    public WebConfig() {
    }

	@Bean
	public AuditInterceptor pageAuditInterceptor() {
	    return new AuditInterceptor();
	}

    

}
